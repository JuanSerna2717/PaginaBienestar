<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .div_deg {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        label {
            display: inline-block;
            width: 200px;
            padding: 10px;
        }
        input[type='text'], input[type='number'], input[type='email'] {
           width: 200px;
           height: 30px;
        }
        textarea {
            width: 400px;
            height: 100px;
        }
    </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.slidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar Navigation end-->
    <div class="page-content">
      <div class="page-header">
        <div class="container-fluid">
          <h2>Actualizar Información De Usuario</h2>
          <div class="div_deg">
            <form action="<?php echo e(url('edit_usuario', $user->id)); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div>
                <label>Nombre</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>">
              </div>
              <div>
                <label>Numero de documento</label>
                <input type="number" name="identification" value="<?php echo e($user->identification); ?>">
              </div>
              <div>
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>">
              </div>
              <div>
                <label>Tipo de usuario</label>
                <select name="usertype">
                  <option value="<?php echo e($user->usertype); ?>">selecione...</option>
                  <option value="admin">admin</option>
                  <option value="user">user</option>
                  <option value="user">bienestar</option>
                </select>
              </div>
              <div>
                <input class="btn btn-success" type="submit" value="Actualizar Usuario">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo e(asset('admincss/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery.cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/charts-home.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/front.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\pagina_bienestar\resources\views/admin/update_page_user.blade.php ENDPATH**/ ?>