

<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <style type="text/css">

    .div_deg{

        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 60px;
    }

    .table_deg{
        
        border-radius: 10px;
      
    }

    th
    {
       background-color: green;
       color: white;
       font-size: 19px;
       font-weight:bold;
       padding: 15px;
       
    }


    td
    {
        border: 1px groove green;
        text-align: center;
        color: white;
        height: 50px;
        
    }


    </style>


  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.slidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
          

          <div class="div_deg">

            <table class="table_deg">

              <tr>

                <th>Nombre completo</th>

                <th>Número de identificación</th>

                <th>Email</th>

                <th>Tipo de usuario</th>

                <th>Editar</th>

                <th>Eliminar</th>

              </tr>


          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr>

                <td><?php echo e($user->name); ?></td>

                <td><?php echo e($user->identification); ?></td>

                <td><?php echo e($user->email); ?></td>

                <td><?php echo e($user->usertype); ?></td>

                <td>
                    <a class="btn btn-success" href="<?php echo e(url('update_usuario', $user->id)); ?>">Editar</a>
                </td>

                <td>
                    <a class=" btn btn-danger" onclick="confirmation(event)" href="<?php echo e(url('delete_usuario',$user->id)); ?>">Eliminar</a>
                </td>

              </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>


      </div>

    <div class="div_deg">
      <?php echo e($users->onEachSide(1)->links()); ?>

    </div>



    </div>
</div>
</div>


    <!-- JavaScript files-->

<?php echo $__env->make('admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\pagina_bienestar\resources\views/admin/view_usuarios.blade.php ENDPATH**/ ?>