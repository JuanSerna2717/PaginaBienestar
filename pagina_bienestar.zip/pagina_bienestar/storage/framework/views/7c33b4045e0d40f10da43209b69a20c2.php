

<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <style type="text/css">

    .div_deg{

        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 60px;
    }

    .table_deg{
        border: 2px solid greenyellow;
    }

    th
    {
       background-color: skyblue;
       color: white;
       font-size: 19px;
       font-weight:bold;
       padding: 15px;
    }


    td
    {
        border: 1px solid skyblue;
        text-align: center;
    }


    </style>


  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.slidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
          

          <div class="div_deg">


            <table class="table_deg">

                <tr>

                    <th>Titulo del Servicio</th>

                    <th>Descripción</th>

                    <th>Categoría</th>

                    <th>Imagen</th>

                    <th>Editar</th>

                    <th>Eliminar</th>

                </tr>


            <?php $__currentLoopData = $servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

                <td><?php echo e($servicios->title); ?></td>

                <td><?php echo Str::limit($servicios->description,100); ?></td>

                <td><?php echo e($servicios->category); ?></td>

                <td>
                    <img height="120" widht="120"src="products/<?php echo e($servicios->image); ?>" alt="">
                </td>

                <td>
                    <a class="btn btn-success" href="<?php echo e(url('update_servicio', $servicios->id)); ?>">Editar</a>
                </td>

                <td>
                    <a class=" btn btn-danger" onclick="confirmation(event)" href="<?php echo e(url('delete_servicio',$servicios->id)); ?>">Eliminar</a>
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>

        
          </div>

          <div class="div_deg">
          <?php echo e($servicio->onEachSide(1)->links()); ?>

          </div>
        
          

        </div>
      </div>
    </div>

    <!-- JavaScript files-->

<?php echo $__env->make('admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\pagina_bienestar\resources\views/admin/view_servicio.blade.php ENDPATH**/ ?>