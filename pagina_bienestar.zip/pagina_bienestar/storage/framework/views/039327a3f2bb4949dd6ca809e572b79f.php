<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">
        .div_deg
        {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 60px;

        }

        h1
        {
            color: white;
        }

        label
        {
            display: inline-block;
            width: 250px;
            font-size: 18px!important;
            color: white!important;
        }


        input[type='text']
        {
            width: 251px;
            height: 30px;
        }

        textarea
        {
            width: 300px;
            height: 80px;
        }


        .input_deg
        {
            padding: 5px;
        }

    </style>




  </head>
  <body>

     <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.slidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">



          <h1>Añadir Evento</h1>

          <div class="div_deg">

            <form action="<?php echo e(url('upload_evento')); ?>" method="Post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="input_deg">
                    <label>Titulo del Evento</label>
                    <input type="text" name="title">
                </div>
                
                <div class="input_deg">
                    <label>Descripción</label>
                    <textarea name="description" require></textarea>
                </div>

                <div class="input_deg">
                    <label>Fecha Del evento</label>
                    <input type="date" name="fecha_evento">
                </div>

                <div class="input_deg">
                    <label>Aforo</label>
                    <input type="text" name="aforo">
                </div>


                <div class="input_deg">
                    <label>Fecha Limite Inscripciones</label>
                    <input type="date" name="dates">
                </div>


                <div class="input_deg">
                    <label>Imagen del Evento</label>
                    <input type="file" name="image">
                </div>


                

                <div class="input_deg">
                    <input class="btn btn-success" type="submit" value="Añadir Servicio">
                </div>

            </form>


          </div>

        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo e(('admincss/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(('admincss/vendor/popper.js/umd/popper.min.js')); ?>"> </script>
    <script src="<?php echo e(('admincss/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(('admincss/vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>
    <script src="<?php echo e(('admincss/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(('admincss/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(('admincss/js/charts-home.js')); ?>"></script>
    <script src="<?php echo e(('admincss/js/front.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\pagina_bienestar\resources\views/admin/add_evento.blade.php ENDPATH**/ ?>