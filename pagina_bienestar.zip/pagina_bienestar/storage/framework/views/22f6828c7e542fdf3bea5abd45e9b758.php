<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <style type="text/css">
        .div_deg
        {
            display:flex;
            justify-content: center;
            align-items: center;
        }
        
        label
        {
            display: inline-block;
            width: 200px;
            padding: 10px;
        }

        input[type='text']
        {
           width: 200px;
           height: 30px;

        }

        textarea
        {
            width: 400px;
            height: 100px;
        }


    </style>

  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.slidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
          


            <h2>Actualizar Información Servicios</h2>

            <div class="div_deg">

            <form action="<?php echo e(url('edit_servicio', $data->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <label>Titulo</label>
                <input type="text" name="title" value="<?php echo e($data->title); ?>">
            </div>

            <div>
                <label>Descripción</label>
                <textarea name="description"><?php echo e($data->description); ?></textarea>
            </div>

            <div>
                <label>Categoria</label>
                <select name="category">

                    <option value="<?php echo e($data->category); ?>"><?php echo e($data->
                        category); ?></option>
                    
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
            </div>

            <div>
                <label>Imagen actual</label>
                <img width="150" src="/products/<?php echo e($data->image); ?>">
            </div>

            <div>
                <label>Nueva Imagen</label>
                <input type="file" name="image">
            </div>

            <div>
                <input class="btn btn-success"type="submit" value="Actualizar Servicio">
            </div>

            </form>


            </div>






        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo e(asset('admincss/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery.cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/charts-home.js')); ?>"></script>
    <script src="<?php echo e(asset('admincss/js/front.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\pagina_bienestar\resources\views/admin/update_page.blade.php ENDPATH**/ ?>